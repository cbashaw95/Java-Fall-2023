package puzzles.common.solver;
/**
 * solver for the clock puzzle.
 *
 * @author Connor Bashaw
 */
public class Solver {
    // TODO
}
